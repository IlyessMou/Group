package com.example.quizzapp.controllers;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.quizzapp.models.LoginUser;
import com.example.quizzapp.models.Question;
import com.example.quizzapp.models.Quiz;
import com.example.quizzapp.models.Result;
import com.example.quizzapp.models.User;
import com.example.quizzapp.repositories.QuestionRepository;
import com.example.quizzapp.repositories.QuizRepository;
import com.example.quizzapp.repositories.ResultRepository;
import com.example.quizzapp.services.QuestionService;
import com.example.quizzapp.services.QuizService;
import com.example.quizzapp.services.UserService;

import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;

@Controller
public class MainController {

    @Autowired
    private UserService userService;

    @Autowired
    private QuizService quizService;

    @Autowired
    private QuestionService questionService;

    @Autowired
    private ResultRepository resultRepository;

    @Autowired
    private QuizRepository quizRepository;

    @Autowired
    private QuestionRepository questionRepository;

    // Display the homepage with login and registration forms
    @GetMapping("/")
    public String index(Model model) {
        model.addAttribute("newUser", new User());
        model.addAttribute("newLogin", new LoginUser());
        return "index.jsp"; 
    }

    // Handle user registration
    @PostMapping("/register")
    public String register(@Valid @ModelAttribute("newUser") User newUser, 
            BindingResult result, Model model, HttpSession session) {
        User user = userService.register(newUser, result);
        if(result.hasErrors()) {
            model.addAttribute("newLogin", new LoginUser());
            return "index.jsp";
        }
        session.setAttribute("userId", user.getId());
        return "redirect:/home";
    }

    // Handle user login
    @PostMapping("/login")
    public String login(@Valid @ModelAttribute("newLogin") LoginUser newLogin, 
            BindingResult result, Model model, HttpSession session) {
        User user = userService.login(newLogin, result);
        if(result.hasErrors()) {
            model.addAttribute("newUser", new User());
            return "index.jsp";
        }
        session.setAttribute("userId", user.getId());
        return "redirect:/home";
    }

    // Display the home page with quizzes and user data
    @GetMapping("/home")
    public String home(Model model, HttpSession session) {
        if (session.getAttribute("userId") == null) {
            return "redirect:/"; 
        }

        User user = userService.findById((Long) session.getAttribute("userId")).orElse(null);
        List<Quiz> publicQuizzes = quizRepository.findByIsPrivateFalse();
    	System.out.println("Public Quizzes: " + publicQuizzes);
    	System.out.println("Number of public quizzes: " + publicQuizzes.size());

    	System.out.println("User : " + user);
        if (user != null) {
            model.addAttribute("user", user);
            model.addAttribute("quizzes", publicQuizzes); 
            model.addAttribute("quizCode", ""); 
        }
        
        return "home.jsp"; 
    }

    // Handle user logout
    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate(); 
        return "redirect:/"; 
    }

    // Display the page for creating a new quiz
    @GetMapping("/quiz/create")
    public String createQuizPage(Model model, HttpSession session) {
        if (session.getAttribute("userId") == null) {
            return "redirect:/"; 
        }
        System.out.println("User is logged in");
        model.addAttribute("newQuiz", new Quiz());
        return "createQuiz.jsp"; 
    }

    @PostMapping("/quiz/create")
    public String createQuiz(@ModelAttribute Quiz quiz, HttpSession session) {
        switch (quiz.getDifficulty().toLowerCase()) {
            case "easy":
                quiz.setNumQuestions(5);
                break;
            case "medium":
                quiz.setNumQuestions(10);
                break;
            case "hard":
                quiz.setNumQuestions(12);
                break;
            case "challenge":
                quiz.setNumQuestions(15);
                break;
            default:
                throw new IllegalArgumentException("Invalid difficulty level");
        }

        User user = userService.findById((Long) session.getAttribute("userId")).orElse(null);
        if (user != null) {
            quiz.setCreator(user); 
        } else {
            
            return "redirect:/"; 
        }

        quizRepository.save(quiz); 
        return "redirect:/quiz/" + quiz.getId() + "/add-questions";  
    }

    // Show the add questions form
    @GetMapping("/quiz/{id}/add-questions")
    public String addQuestionsForm(@PathVariable Long id, Model model, HttpSession session) {
        if (session.getAttribute("userId") == null) {
            return "redirect:/"; 
        }
        Quiz quiz = quizRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid quiz ID"));
        model.addAttribute("quiz", quiz);
        model.addAttribute("newQuestion", new Question());  
        return "addQuestions.jsp";  
    }

    @PostMapping("/quiz/{id}/add-question")
    public String addQuestion(@PathVariable Long id, @ModelAttribute("quiz") Quiz quiz, Model model) {
        Quiz existingQuiz = quizRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid quiz ID"));

        for (Question question : quiz.getQuestions()) {
            question.setQuiz(existingQuiz);  
            questionRepository.save(question);  
        }

        model.addAttribute("quiz", existingQuiz);
        model.addAttribute("newQuestion", new Question());  
        return "redirect:/home";  
    }

    // Display a quiz and its questions
    @GetMapping("/quiz/{id}")
    public String showQuiz(@PathVariable("id") Long quizId, Model model, HttpSession session) {
        if (session.getAttribute("userId") == null) {
            return "redirect:/"; 
        }

        Quiz quiz = quizService.findById(quizId).orElse(null);
        if (quiz == null) {
            return "redirect:/home"; 
        }

        model.addAttribute("quiz", quiz);
        model.addAttribute("questions", quiz.getQuestions()); 
        return "quizPage.jsp"; 
    }

    // Submit answers and show results
    @PostMapping("/quiz/{id}/submit")
    public String submitQuiz(@PathVariable("id") Long quizId, 
                             @RequestParam Map<String, String> answers, 
                             HttpSession session, Model model) {
        if (session.getAttribute("userId") == null) {
            return "redirect:/"; 
        }

        Quiz quiz = quizService.findById(quizId).orElse(null);
        if (quiz == null) {
            return "redirect:/home"; 
        }

        User user = userService.findById((Long) session.getAttribute("userId")).orElse(null);
        if (user == null) {
            return "redirect:/"; 
        }

        int score = 0;
        List<Question> questions = quiz.getQuestions();
        System.out.println("Number of questions in quiz: " + questions.size());

        for (Question question : questions) {
            String correctAnswer = question.getCorrectAnswer(); 
            
            String userAnswer = answers.get("question-" + question.getId());

            String userSelectedAnswerContent = null;
            if (userAnswer != null) {
                switch (userAnswer) {
                    case "A":
                        userSelectedAnswerContent = question.getOptionA();
                        break;
                    case "B":
                        userSelectedAnswerContent = question.getOptionB();
                        break;
                    case "C":
                        userSelectedAnswerContent = question.getOptionC();
                        break;
                    case "D":
                        userSelectedAnswerContent = question.getOptionD();
                        break;
                }
            }

            System.out.println("Question ID: " + question.getId());
            System.out.println("Correct Answer: " + correctAnswer);
            System.out.println("User Answer: " + userAnswer + " (Content: " + userSelectedAnswerContent + ")");

          
            if (correctAnswer != null && userSelectedAnswerContent != null && correctAnswer.equals(userSelectedAnswerContent)) {
                score++;
            }
        }

        Result result = new Result(user, quiz, score);
        resultRepository.save(result);

        model.addAttribute("quiz", quiz);
        model.addAttribute("score", score);
        model.addAttribute("totalQuestions", questions.size());

        return "result.jsp"; 
    }


 // Display a private quiz using a code
    @GetMapping("/quiz/access")
    public String accessQuiz(@RequestParam("code") String code, Model model, HttpSession session) {
        if (session.getAttribute("userId") == null) {
            return "redirect:/"; 
        }

        Quiz quiz = quizService.findByCode(code); 
        if (quiz != null) {
            model.addAttribute("quiz", quiz); 
            model.addAttribute("questions", quiz.getQuestions()); 
            return "quizPage.jsp"; 
        } else {
            model.addAttribute("error", "Invalid quiz code"); 
            return "home.jsp"; 
        }
    }

}


