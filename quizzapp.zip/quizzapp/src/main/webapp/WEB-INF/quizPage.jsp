<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ taglib prefix = "c" uri = "http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${quiz.title} - Quiz App</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container mt-5">
        <h2>${quiz.title}</h2>
        <form action="/quiz/${quiz.id}/submit" method="POST">
    <c:forEach var="question" items="${quiz.questions}">
        <div class="mb-3">
            <label class="form-label">${question.content}</label>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="question-${question.id}" value="A" required>
                <label class="form-check-label">${question.optionA}</label>
            </div>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="question-${question.id}" value="B">
                <label class="form-check-label">${question.optionB}</label>
            </div>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="question-${question.id}" value="C">
                <label class="form-check-label">${question.optionC}</label>
            </div>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="question-${question.id}" value="D">
                <label class="form-check-label">${question.optionD}</label>
            </div>
        </div>
    </c:forEach>
    <button type="submit" class="btn btn-success">Submit Quiz</button>
</form>
        
        
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
    