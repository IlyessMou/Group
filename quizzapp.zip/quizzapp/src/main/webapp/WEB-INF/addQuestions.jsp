<%@ taglib uri="http://www.springframework.org/tags/form" prefix="form" %>
<%@ taglib prefix = "c" uri = "http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Add Questions to Quiz</title>
</head>
<body>
    <h2>Add Questions for Quiz: ${quiz.title}</h2>
    <!-- Using form:form to bind the model attributes -->
    <form:form action="/quiz/${quiz.id}/add-question" method="POST" modelAttribute="quiz">
    <c:forEach begin="1" end="${quiz.numQuestions}" var="i">
        <div>
            <h4>Question ${i}</h4>

            <form:label path="questions[${i - 1}].content">Content:</form:label>
            <form:input path="questions[${i - 1}].content" required="true" />

            <form:label path="questions[${i - 1}].optionA">Option A:</form:label>
            <form:input path="questions[${i - 1}].optionA" required="true" />

            <form:label path="questions[${i - 1}].optionB">Option B:</form:label>
            <form:input path="questions[${i - 1}].optionB" required="true" />

            <form:label path="questions[${i - 1}].optionC">Option C:</form:label>
            <form:input path="questions[${i - 1}].optionC" />

            <form:label path="questions[${i - 1}].optionD">Option D:</form:label>
            <form:input path="questions[${i - 1}].optionD" />

            <form:label path="questions[${i - 1}].correctAnswer">Correct Answer:</form:label>
            <form:input path="questions[${i - 1}].correctAnswer" required="true" />
        </div>
        <hr />
    </c:forEach>
    <button type="submit">Submit Questions</button>
</form:form>
    
</body>
</html>
